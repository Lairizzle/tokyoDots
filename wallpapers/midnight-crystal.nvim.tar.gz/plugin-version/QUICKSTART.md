# 🚀 Quick Start Guide

## Installation in 3 Steps

### Step 1: Copy the Plugin

Copy the entire `midnight-crystal.nvim` folder to your Neovim config directory:

```bash
cp -r midnight-crystal.nvim ~/.config/nvim/plugins/
```

Or create a symbolic link:

```bash
ln -s /path/to/midnight-crystal.nvim ~/.config/nvim/plugins/midnight-crystal.nvim
```

### Step 2: Configure lazy.nvim

Add this to your lazy.nvim plugin configuration:

**Method A - From Local Directory:**

```lua
-- In ~/.config/nvim/lua/plugins/theme.lua (or any plugin file)
return {
  {
    dir = "~/.config/nvim/plugins/midnight-crystal.nvim",
    lazy = false,
    priority = 1000,
    opts = {},
  }
}
```

**Method B - From GitHub (once uploaded):**

```lua
return {
  {
    "yourusername/midnight-crystal.nvim",
    lazy = false,
    priority = 1000,
    opts = {},
  }
}
```

### Step 3: Restart Neovim

```bash
nvim
```

The theme will automatically load!

---

## Alternative: Manual Setup

If you want more control:

```lua
{
  dir = "~/.config/nvim/plugins/midnight-crystal.nvim",
  lazy = false,
  priority = 1000,
  config = function()
    vim.opt.termguicolors = true
    require("midnight-crystal").setup()
    vim.cmd("colorscheme midnight-crystal")
  end,
}
```

---

## Using with Different Plugin Managers

### Packer

```lua
use {
  '~/.config/nvim/plugins/midnight-crystal.nvim',
  config = function()
    require("midnight-crystal").setup()
    vim.cmd("colorscheme midnight-crystal")
  end
}
```

### Vim-Plug

```vim
Plug '~/.config/nvim/plugins/midnight-crystal.nvim'

lua << EOF
require("midnight-crystal").setup()
vim.cmd("colorscheme midnight-crystal")
EOF
```

---

## Verify Installation

After restarting Neovim:

```vim
:colorscheme midnight-crystal
```

Or check your current colorscheme:

```vim
:echo g:colors_name
```

Should output: `midnight-crystal`

---

## Troubleshooting

**Theme not loading?**

1. Verify the directory path:
   ```bash
   ls ~/.config/nvim/plugins/midnight-crystal.nvim
   ```

2. Check for errors:
   ```vim
   :messages
   ```

3. Manually load:
   ```vim
   :lua require("midnight-crystal").setup()
   :colorscheme midnight-crystal
   ```

**Colors look wrong?**

Ensure termguicolors is enabled:
```lua
vim.opt.termguicolors = true
```

---

That's it! Enjoy your new theme! 🌙✨
