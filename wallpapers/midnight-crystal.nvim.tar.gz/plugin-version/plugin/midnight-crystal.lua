-- ============================================================================
-- Midnight Crystal - Plugin Configuration
-- This file is automatically sourced by lazy.nvim
-- ============================================================================

return {
  name = "midnight-crystal",
  setup = function()
    require('midnight-crystal').setup()
  end,
}
