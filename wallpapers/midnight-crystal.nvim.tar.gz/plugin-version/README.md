# 🌙 Midnight Crystal

A beautiful, comprehensive Neovim colorscheme featuring deep purples, blues, and magentas with excellent syntax highlighting coverage.

![Neovim](https://img.shields.io/badge/NeoVim-%2357A143.svg?&style=for-the-badge&logo=neovim&logoColor=white)
![Lua](https://img.shields.io/badge/lua-%232C2D72.svg?style=for-the-badge&logo=lua&logoColor=white)

## ✨ Features

- 🎨 **Complete coverage** - UI elements, syntax highlighting, and LSP support
- 🔌 **Plugin support** - Treesitter, LSP, Telescope, nvim-tree, and 20+ popular plugins
- 🌈 **Rich palette** - Carefully crafted colors for optimal readability
- ⚡ **Optimized** - Fast loading with clean highlight groups
- 📝 **Full syntax** - Comprehensive language support via Treesitter
- 🚀 **Easy install** - Works with all popular plugin managers

## 🎨 Palette

```lua
background      = '#271224'  -- Main background
background_alt  = '#291E37'  -- Floating windows
foreground      = '#6391D8'  -- Main text
foreground_dim  = '#8FB3FF'  -- Comments
foreground_soft = '#9A8FEF'  -- Functions, types
purple_dark     = '#BB9AF7'  -- Keywords
info_cyan       = '#73daca'  -- Strings
warning_yellow  = '#E0AF68'  -- Numbers, warnings
error_red       = '#F7768E'  -- Errors
hint_purple     = '#BB9AF7'  -- Hints, macros
```

## 📦 Installation

### [lazy.nvim](https://github.com/folke/lazy.nvim) (Recommended)

```lua
{
  "yourusername/midnight-crystal.nvim",
  lazy = false,
  priority = 1000,
  opts = {},
}
```

Or with custom config directory:

```lua
{
  dir = "~/.config/nvim/plugins/midnight-crystal.nvim",
  lazy = false,
  priority = 1000,
  config = function()
    require("midnight-crystal").setup()
    vim.cmd("colorscheme midnight-crystal")
  end,
}
```

### [packer.nvim](https://github.com/wbthomason/packer.nvim)

```lua
use {
  "yourusername/midnight-crystal.nvim",
  config = function()
    require("midnight-crystal").setup()
    vim.cmd("colorscheme midnight-crystal")
  end
}
```

### [vim-plug](https://github.com/junegunn/vim-plug)

```vim
Plug 'yourusername/midnight-crystal.nvim'

" In your init.vim or after plug#end()
lua << EOF
require("midnight-crystal").setup()
vim.cmd("colorscheme midnight-crystal")
EOF
```

### Manual Installation

Clone this repository into your Neovim config:

```bash
git clone https://github.com/yourusername/midnight-crystal.nvim \
  ~/.config/nvim/plugins/midnight-crystal.nvim
```

Then add to your config:

```lua
-- In init.lua
vim.opt.rtp:append("~/.config/nvim/plugins/midnight-crystal.nvim")
require("midnight-crystal").setup()
vim.cmd("colorscheme midnight-crystal")
```

## 🚀 Usage

### Basic Usage

```lua
-- In your init.lua
require("midnight-crystal").setup()
```

### Using `:colorscheme` command

```vim
:colorscheme midnight-crystal
```

Or in Lua:

```lua
vim.cmd("colorscheme midnight-crystal")
```

### With Options (Future Support)

```lua
require("midnight-crystal").setup({
  -- Custom options can be added here in future versions
  -- transparent = false,
  -- terminal_colors = true,
})
```

## 🔌 Supported Plugins

### Core Enhancements
- ✅ [nvim-treesitter](https://github.com/nvim-treesitter/nvim-treesitter) - Advanced syntax highlighting
- ✅ Native LSP - Full diagnostic and reference support
- ✅ [nvim-cmp](https://github.com/hrsh7th/nvim-cmp) - Completion menu styling

### File Navigation
- ✅ [telescope.nvim](https://github.com/nvim-telescope/telescope.nvim) - Fuzzy finder
- ✅ [nvim-tree.lua](https://github.com/nvim-tree/nvim-tree.lua) - File explorer
- ✅ [neo-tree.nvim](https://github.com/nvim-neo-tree/neo-tree.nvim) - Alternative file explorer

### UI Enhancements
- ✅ [which-key.nvim](https://github.com/folke/which-key.nvim) - Keybinding helper
- ✅ [bufferline.nvim](https://github.com/akinsho/bufferline.nvim) - Buffer tabs
- ✅ [lualine.nvim](https://github.com/nvim-lualine/lualine.nvim) - Statusline
- ✅ [alpha-nvim](https://github.com/goolord/alpha-nvim) - Dashboard
- ✅ [dashboard-nvim](https://github.com/nvimdev/dashboard-nvim) - Alternative dashboard
- ✅ [indent-blankline.nvim](https://github.com/lukas-reineke/indent-blankline.nvim) - Indent guides
- ✅ [nvim-notify](https://github.com/rcarriga/nvim-notify) - Notifications
- ✅ [noice.nvim](https://github.com/folke/noice.nvim) - UI improvements

### Git Integration
- ✅ [gitsigns.nvim](https://github.com/lewis6991/gitsigns.nvim) - Git decorations
- ✅ [neogit](https://github.com/NeogitOrg/neogit) - Git interface

### Language Support
- ✅ Markdown - Enhanced styling
- ✅ All Treesitter languages
- ✅ LSP semantic tokens

## 🎯 Complete Example Configuration

```lua
-- ~/.config/nvim/lua/plugins/theme.lua
return {
  {
    "yourusername/midnight-crystal.nvim",
    lazy = false,
    priority = 1000,
    config = function()
      -- Ensure termguicolors is enabled
      vim.opt.termguicolors = true
      
      -- Load the theme
      require("midnight-crystal").setup()
      
      -- Set colorscheme
      vim.cmd("colorscheme midnight-crystal")
    end,
  },
  
  -- Optional: Configure lualine with matching theme
  {
    "nvim-lualine/lualine.nvim",
    dependencies = { "midnight-crystal.nvim" },
    config = function()
      require("lualine").setup({
        options = {
          theme = {
            normal = {
              a = { bg = "#6391D8", fg = "#271224", gui = "bold" },
              b = { bg = "#3B2A46", fg = "#8FB3FF" },
              c = { bg = "#271224", fg = "#6391D8" },
            },
            insert = { a = { bg = "#73daca", fg = "#271224", gui = "bold" } },
            visual = { a = { bg = "#BB9AF7", fg = "#271224", gui = "bold" } },
            replace = { a = { bg = "#F7768E", fg = "#271224", gui = "bold" } },
          },
        },
      })
    end,
  },
}
```

## 🎨 Customization

### Override Specific Highlights

```lua
require("midnight-crystal").setup()

-- Override highlights after loading
vim.api.nvim_set_hl(0, "Comment", { 
  fg = "#your_color", 
  italic = true 
})
```

### Access the Palette

```lua
local colors = require("midnight-crystal").palette

-- Use colors in your config
vim.api.nvim_set_hl(0, "CustomGroup", { 
  fg = colors.accent_primary,
  bg = colors.background_alt,
})
```

## 📂 Project Structure

```
midnight-crystal.nvim/
├── colors/
│   └── midnight-crystal.lua    # Colorscheme loader
├── lua/
│   └── midnight-crystal/
│       └── init.lua            # Main theme file
├── plugin/
│   └── midnight-crystal.lua    # Auto-load configuration
└── README.md
```

## 🐛 Troubleshooting

### Colors not showing correctly

Ensure `termguicolors` is enabled:

```lua
vim.opt.termguicolors = true
```

### Theme not loading with lazy.nvim

Make sure `priority = 1000` is set to load the theme before other plugins:

```lua
{
  "yourusername/midnight-crystal.nvim",
  lazy = false,      -- Load immediately
  priority = 1000,   -- Load before other plugins
}
```

### Transparent Background

```lua
require("midnight-crystal").setup()

-- Make background transparent
vim.api.nvim_set_hl(0, "Normal", { fg = "#6391D8", bg = "NONE" })
vim.api.nvim_set_hl(0, "NormalFloat", { fg = "#6391D8", bg = "NONE" })
```

## 📝 License

MIT License - feel free to use and modify!

## 🙏 Credits

Inspired by the beautiful color palettes of Tokyo Night, Catppuccin, and Rose Pine.

---

**Enjoy coding with Midnight Crystal! 🌙✨**
