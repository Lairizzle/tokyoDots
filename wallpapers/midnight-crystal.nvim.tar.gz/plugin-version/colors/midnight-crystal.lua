-- ============================================================================
-- Midnight Crystal Colorscheme Loader
-- This file allows using: colorscheme midnight-crystal
-- ============================================================================

lua << EOF
require('midnight-crystal').load()
EOF
